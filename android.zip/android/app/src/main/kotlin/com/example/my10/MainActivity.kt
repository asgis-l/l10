package com.example.my10

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
